# Expense Tracker - Khata-like (Java Full Stack)

This is a simple expense tracker (in the spirit of Khata Book) built with:
- Backend: Spring Boot (Java 17), Spring Data JPA, H2 in-memory DB
- Frontend: Static HTML + JS served by Spring

Features implemented:
- Add income & expenses
- Categorize transactions
- View transaction history
- Monthly summary report

## Run locally

1. Build & run with Maven:
   ```bash
   mvn spring-boot:run
   ```
2. Open the app in a browser:
   `http://localhost:8080/`

3. H2 console:
   `http://localhost:8080/h2` (JDBC URL already configured)

4. API docs (OpenAPI / Swagger UI):
   `http://localhost:8080/swagger-ui/index.html`

## Notes
- Default categories are pre-populated via `data.sql`.
- This is a starter project — extend authentication, export/backup, and better UI as needed.
