package com.example.expensetracker.controller;

import com.example.expensetracker.model.Category;
import com.example.expensetracker.repository.CategoryRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
    private final CategoryRepository repo;

    public CategoryController(CategoryRepository repo){
        this.repo = repo;
    }

    @GetMapping
    public List<Category> all(){ return repo.findAll(); }

    @PostMapping
    public Category create(@RequestBody Category category){ return repo.save(category); }
}
