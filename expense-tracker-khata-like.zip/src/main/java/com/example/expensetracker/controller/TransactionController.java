package com.example.expensetracker.controller;

import com.example.expensetracker.model.Transaction;
import com.example.expensetracker.repository.TransactionRepository;
import com.example.expensetracker.repository.CategoryRepository;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {
    private final TransactionRepository txRepo;
    private final CategoryRepository catRepo;

    public TransactionController(TransactionRepository txRepo, CategoryRepository catRepo){
        this.txRepo = txRepo;
        this.catRepo = catRepo;
    }

    @GetMapping
    public List<Transaction> all(){
        return txRepo.findAll();
    }

    @GetMapping("/byDate")
    public List<Transaction> byDateRange(@RequestParam String start, @RequestParam String end){
        LocalDateTime s = LocalDateTime.parse(start);
        LocalDateTime e = LocalDateTime.parse(end);
        return txRepo.findByDateTimeBetweenOrderByDateTimeDesc(s,e);
    }

    @PostMapping
    public Transaction create(@RequestBody Transaction tx){
        if (tx.getDateTime() == null) tx.setDateTime(LocalDateTime.now());
        if (tx.getCategory() != null && tx.getCategory().getId() != null){
            catRepo.findById(tx.getCategory().getId()).ifPresent(tx::setCategory);
        }
        return txRepo.save(tx);
    }
}
