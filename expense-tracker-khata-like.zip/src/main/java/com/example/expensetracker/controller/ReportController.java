package com.example.expensetracker.controller;

import com.example.expensetracker.model.Transaction;
import com.example.expensetracker.repository.TransactionRepository;
import org.springframework.web.bind.annotation.*;
import java.time.*;
import java.util.*;
import java.util.stream.*;

@RestController
@RequestMapping("/api/reports")
public class ReportController {
    private final TransactionRepository txRepo;

    public ReportController(TransactionRepository txRepo){ this.txRepo = txRepo; }

    @GetMapping("/summary/monthly")
    public Map<String, Object> monthlySummary(@RequestParam int year, @RequestParam int month){
        LocalDate start = LocalDate.of(year, month, 1);
        LocalDate end = start.withDayOfMonth(start.lengthOfMonth());
        LocalDateTime s = start.atStartOfDay();
        LocalDateTime e = end.atTime(23,59,59);
        List<Transaction> txs = txRepo.findByDateTimeBetweenOrderByDateTimeDesc(s,e);

        double totalIncome = txs.stream().filter(Transaction::isIncome).mapToDouble(Transaction::getAmount).sum();
        double totalExpense = txs.stream().filter(t->!t.isIncome()).mapToDouble(Transaction::getAmount).sum();

        Map<String, Object> map = new LinkedHashMap<>();
        map.put("year", year);
        map.put("month", month);
        map.put("totalIncome", totalIncome);
        map.put("totalExpense", totalExpense);
        map.put("net", totalIncome - totalExpense);
        map.put("transactionsCount", txs.size());
        return map;
    }
}
