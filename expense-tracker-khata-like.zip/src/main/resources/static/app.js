const $ = id => document.getElementById(id);

async function fetchJSON(path, opts){ 
  const res = await fetch(path, opts);
  return res.ok ? res.json() : Promise.reject(await res.text());
}

async function loadCategories(){
  const cats = await fetchJSON('/api/categories');
  const sel = $('category');
  sel.innerHTML = cats.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
  return cats;
}

async function loadTransactions(){
  const txs = await fetchJSON('/api/transactions');
  const container = $('transactions');
  container.innerHTML = txs.map(t=>`
    <div class="tx">
      <div>
        <strong>${t.title}</strong><br/>
        <small>${t.category ? t.category.name : 'Uncategorized'} • ${new Date(t.dateTime).toLocaleString()}</small>
      </div>
      <div class="${t.income ? 'income' : 'expense'}">${t.income?'+':'-'} ₹${t.amount.toFixed(2)}</div>
    </div>
  `).join('');
  updateBalance(txs);
}

function updateBalance(txs){
  const totalIncome = txs.filter(t=>t.income).reduce((s,t)=>s+t.amount,0);
  const totalExpense = txs.filter(t=>!t.income).reduce((s,t)=>s+t.amount,0);
  $('balance').innerHTML = `<strong>Income:</strong> ₹${totalIncome.toFixed(2)} &nbsp; <strong>Expense:</strong> ₹${totalExpense.toFixed(2)} &nbsp; <strong>Net:</strong> ₹${(totalIncome-totalExpense).toFixed(2)}`;
}

$('txForm').addEventListener('submit', async e=>{
  e.preventDefault();
  const payload = {
    title: $('title').value,
    amount: parseFloat($('amount').value),
    income: $('type').value === 'income',
    category: { id: parseInt($('category').value) }
  };
  await fetchJSON('/api/transactions', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  $('title').value=''; $('amount').value='';
  loadTransactions();
});

async function loadReport(){
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth()+1;
  const data = await fetchJSON(`/api/reports/summary/monthly?year=${year}&month=${month}`);
  $('report').innerHTML = `<div><strong>${month}/${year}</strong> — Income: ₹${data.totalIncome.toFixed(2)}, Expense: ₹${data.totalExpense.toFixed(2)}, Net: ₹${data.net.toFixed(2)}</div>`;
}

async function init(){
  await loadCategories();
  await loadTransactions();
  await loadReport();
}
init();
